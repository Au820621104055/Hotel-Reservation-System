package com.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.service.*;
import com.utili.ApplicationUtil;

public class UserInterface {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ApplicationUtil util = new ApplicationUtil();

    private static final RIResidentService riService = new RIResidentService();
    private static final NRIResidentService nriService = new NRIResidentService();
    private static final RoomService roomService = new RoomService();
    private static final BookingService bookingService = new BookingService();
    private static final PaymentService paymentService = new PaymentService();
    private static final ManagerService managerService = new ManagerService();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Sweet Homes Regency Hotel Reservation System ===");
            System.out.println("1. Manage RI Residents");
            System.out.println("2. Manage NRI Residents");
            System.out.println("3. Manage Rooms");
            System.out.println("4. Manage Bookings");
            System.out.println("5. Generate Payments");
            System.out.println("6. Manager View");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = util.getIntInput(scanner);

            switch (choice) {
                case 1 -> manageRIResidents();
                case 2 -> manageNRIResidents();
                case 3 -> manageRooms();
                case 4 -> manageBookings();
                case 5 -> managePayments();
                case 6 -> managerMenu();
                case 7 -> {
                    System.out.println("Thank you for using Sweet Homes Regency. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    // === RI RESIDENT ===
    private static void manageRIResidents() {
        System.out.println("\n-- RI Resident Management --");
        System.out.println("1. Add RI Residents");
        System.out.println("2. Update Resident Info");
        System.out.println("3. View Resident");
        System.out.println("4. Delete Resident");
        System.out.print("Enter choice: ");
        switch (util.getIntInput(scanner)) {
            case 1 -> {
                System.out.println("Enter RI Residents (format: Name:Age:Gender:Contact:Email:Address:Adults:Children12:Children5:StayDays:Type:Aadhar), one per line. Type 'exit' to finish:");
                List<String> lines = ApplicationUtil.readLines(scanner);
                var list = riService.buildRIResidentList(lines);
                boolean result = riService.addRIResidentList(list);
                System.out.println(result ? "Residents added." : "Failed to add.");
            }
            case 2 -> updateRIResident();
            case 3 -> {
                System.out.print("Enter Resident ID to view: ");
                System.out.println(riService.retreiveRIResidentDetails(scanner.nextLine()));
            }
            case 4 -> {
                System.out.print("Enter Resident ID to delete: ");
                boolean res = riService.deleteRIResidentDetailsFromDB(scanner.nextLine());
                System.out.println(res ? "Deleted." : "Not found.");
            }
            default -> System.out.println("Invalid choice");
        }
    }

    private static void updateRIResident() {
        System.out.println("1. Update Phone by ID\n2. Update Phone by Aadhar\n3. Update Phone by Contact\n4. Update Occupancy by ID\n5. Update Occupancy by Aadhar\n6. Update Occupancy by Contact");
        int ch = util.getIntInput(scanner);
        switch (ch) {
            case 1 -> {
                System.out.print("Resident ID: ");
                String id = scanner.nextLine();
                System.out.print("New Phone: ");
                long phone = Long.parseLong(scanner.nextLine());
                System.out.println(riService.updateRIResidentPhoneNumberUsingResidentId(id, phone) ? "Updated." : "Failed.");
            }
            case 2 -> {
                System.out.print("Aadhar: ");
                long idProof = Long.parseLong(scanner.nextLine());
                System.out.print("New Phone: ");
                long phone = Long.parseLong(scanner.nextLine());
                System.out.println(riService.updateRIResidentPhoneNumberUsingIdProof(idProof, phone) ? "Updated." : "Failed.");
            }
            case 3 -> {
                System.out.print("Old Contact: ");
                long old = Long.parseLong(scanner.nextLine());
                System.out.print("New Phone: ");
                long phone = Long.parseLong(scanner.nextLine());
                System.out.println(riService.updateRIResidentPhoneNumberUsingContactNumber(old, phone) ? "Updated." : "Failed.");
            }
            case 4, 5, 6 -> {
                System.out.print("Adults: "); int ad = util.getIntInput(scanner);
                System.out.print("Children > 12: "); int ch12 = util.getIntInput(scanner);
                System.out.print("Children > 5: "); int ch5 = util.getIntInput(scanner);
                boolean updated = switch (ch) {
                    case 4 -> {
                        System.out.print("Resident ID: ");
                        yield riService.updateOccupancyUsingResidentId(scanner.nextLine(), ad, ch12, ch5);
                    }
                    case 5 -> {
                        System.out.print("Aadhar: ");
                        yield riService.updateOccupancyUsingIdProof(Long.parseLong(scanner.nextLine()), ad, ch12, ch5);
                    }
                    default -> {
                        System.out.print("Contact: ");
                        yield riService.updateOccupancyUsingContactNumber(Long.parseLong(scanner.nextLine()), ad, ch12, ch5);
                    }
                };
                System.out.println(updated ? "Updated." : "Failed.");
            }
            default -> System.out.println("Invalid");
        }
    }

    // === TO BE CONTINUED ===
    private static void manageNRIResidents() {
        System.out.println("\n-- NRI Resident Management --");
        System.out.println("1. Add NRI Residents");
        System.out.println("2. Update NRI Info");
        System.out.println("3. Delete NRI Resident");
        System.out.print("Enter choice: ");
        int ch = util.getIntInput(scanner);
        switch (ch) {
            case 1 -> {
                System.out.println("Enter NRI Residents (format: Name:Age:Gender:Contact:Email:Address:Adults:Children12:Children5:StayDays:Type:PassportNo:PassportType:Nationality:Purpose), one per line. Type 'exit' to finish:");
                List<String> lines = ApplicationUtil.readLines(scanner);
                var list = nriService.buildNRIResidentList(lines);
                System.out.println(nriService.addNRIResidentList(list) ? "Added." : "Failed.");
            }
            case 2 -> {
                System.out.println("1. Phone by ID\n2. Phone by Passport\n3. Occupancy by ID\n4. Occupancy by Passport");
                switch (util.getIntInput(scanner)) {
                    case 1 -> {
                        System.out.print("Resident ID: ");
                        String id = scanner.nextLine();
                        System.out.print("New Phone: ");
                        long phone = Long.parseLong(scanner.nextLine());
                        System.out.println(nriService.updateNRIResidentPhoneNumberUsingResidentId(id, phone) ? "Updated." : "Failed.");
                    }
                    case 2 -> {
                        System.out.print("Passport No: ");
                        String pass = scanner.nextLine();
                        System.out.print("New Phone: ");
                        long phone = Long.parseLong(scanner.nextLine());
                        System.out.println(nriService.updateNRIResidentPhoneNumberUsingPassportNumber(pass, phone) ? "Updated." : "Failed.");
                    }
                    case 3, 4 -> {
                        System.out.print("Adults: "); int ad = util.getIntInput(scanner);
                        System.out.print("Children > 12: "); int ch12 = util.getIntInput(scanner);
                        System.out.print("Children > 5: "); int ch5 = util.getIntInput(scanner);
                        if (ch == 3) {
                            System.out.print("Resident ID: ");
                            System.out.println(nriService.updateOccupancyUsingResidentId(scanner.nextLine(), ad, ch12, ch5) ? "Updated." : "Failed.");
                        } else {
                            System.out.print("Passport No: ");
                            System.out.println(nriService.updateOccupancyUsingPassportNumber(scanner.nextLine(), ad, ch12, ch5) ? "Updated." : "Failed.");
                        }
                    }
                    default -> System.out.println("Invalid");
                }
            }
            case 3 -> {
                System.out.print("Enter Resident ID: ");
                System.out.println(nriService.deleteNRIResidentDetailsFromDB(scanner.nextLine()) ? "Deleted." : "Failed.");
            }
            default -> System.out.println("Invalid");
        }
    }

    private static void manageRooms() {
        System.out.println("\n-- Room Management --");
        System.out.println("Enter Room data (format: RoomNo:Floor:Occupied:MaxOccupancy:AC:Pool:Gym), type 'exit' to finish:");
        List<String> lines = ApplicationUtil.readLines(scanner);
        var list = roomService.buildRoomList(lines);
        System.out.println(roomService.addRoomList(list) ? "Rooms added." : "Failed.");

        System.out.print("Want to update occupancy? (yes/no): ");
        if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.print("Room No: ");
            String room = scanner.nextLine();
            System.out.print("Occupied (yes/no): ");
            String occ = scanner.nextLine();
            System.out.println(roomService.updateOccupiedStatus(room, occ) ? "Updated." : "Failed.");
        }
    }

    private static void manageBookings() {
        System.out.println("\n-- Booking Management --");
        System.out.println("Enter Booking data (format: ResidentID:RoomNo:Adults:Ch12:Ch5:Stay:CheckIn:CheckOut:Floor:Package:AC:Pool:Gym:Email:Name), one per line, 'exit' to finish:");
        List<String> lines = ApplicationUtil.readLines(scanner);
        var list = bookingService.buildBookingList(lines);
        System.out.println(bookingService.addBookingList(list) ? "Bookings added." : "Failed.");
    }

    private static void managePayments() {
        System.out.println("\n-- Payment Management --");
        System.out.println("Enter Payment data (format: BookingID:Name:Floor:Room:CheckIn:CheckOut:PaymentDate:Method:Amount), 'exit' to finish:");
        List<String> lines = ApplicationUtil.readLines(scanner);
        var list = paymentService.buildPaymentList(lines);
        System.out.println(paymentService.addPaymentList(list) ? "Payments recorded." : "Failed.");
    }

    private static void managerMenu() {
        System.out.println("\n-- Manager View --");
        System.out.println("1. All Bookings\n2. Available Rooms\n3. Occupied Rooms\n4. Available by Floor\n5. Occupied by Floor\n6. By Check-In Date\n7. By Check-Out Date");
        switch (util.getIntInput(scanner)) {
            case 1 -> managerService.viewAllBookingDetails().forEach(System.out::println);
            case 2 -> managerService.viewAvailableRooms().forEach(System.out::println);
            case 3 -> managerService.viewOccupiedRooms().forEach(System.out::println);
            case 4 -> {
                System.out.print("Enter Floor: ");
                managerService.viewAvailableRoomsOnFloor(scanner.nextLine()).forEach(System.out::println);
            }
            case 5 -> {
                System.out.print("Enter Floor: ");
                managerService.viewOccupiedRoomsOnFloor(scanner.nextLine()).forEach(System.out::println);
            }
            case 6 -> {
                System.out.print("Enter Date (yyyy-MM-dd): ");
                managerService.viewOccupiedRoomsOnCheckInDate(scanner.nextLine()).forEach(System.out::println);
            }
            case 7 -> {
                System.out.print("Enter Date (yyyy-MM-dd): ");
                managerService.viewOccupiedRoomsOnCheckOutDate(scanner.nextLine()).forEach(System.out::println);
            }
            default -> System.out.println("Invalid");
        }
    }
}
