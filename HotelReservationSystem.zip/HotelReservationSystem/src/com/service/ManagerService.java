package com.service;


import java.util.List;
import com.management.ManagerManagement;

public class ManagerService {

    ManagerManagement mgmt = new ManagerManagement();

    public List<String> viewAllBookingDetails() {
        return mgmt.viewBookingDetails();
    }

    public List<String> viewAvailableRooms() {
        return mgmt.viewAvailableRooms();
    }

    public List<String> viewOccupiedRooms() {
        return mgmt.viewOccupiedRooms();
    }

    public List<String> viewAvailableRoomsOnFloor(String floor) {
        return mgmt.viewAvailableRoomsByFloor(floor);
    }

    public List<String> viewOccupiedRoomsOnFloor(String floor) {
        return mgmt.viewOccupiedRoomsByFloor(floor);
    }

    public List<String> viewOccupiedRoomsOnCheckInDate(String date) {
        return mgmt.viewOccupiedRoomsByCheckInDate(date);
    }

    public List<String> viewOccupiedRoomsOnCheckOutDate(String date) {
        return mgmt.viewOccupiedRoomsByCheckOutDate(date);
    }
}