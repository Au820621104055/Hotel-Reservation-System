package com.service;

import java.util.ArrayList;
import java.util.List;

import com.model.Booking;
import com.management.BookingManagement;
import com.utili.ApplicationUtil;

public class BookingService {
    BookingManagement mgmt = new BookingManagement();
    ApplicationUtil au = new ApplicationUtil();
    int id = 0;

    public List<Booking> buildBookingList(List<String> lines) {
        List<Booking> list = new ArrayList<>();
        for (String line : lines) {
            String[] data = line.split(":");
            if (data.length == 15) {
                Booking b = new Booking(generateId(),
                        data[0],
                        data[1],
                        au.stringToInt(data[2]),
                        au.stringToInt(data[3]),
                        au.stringToInt(data[4]),
                        au.stringToInt(data[5]),
                        au.stringToDate(data[6]),
                        au.stringToDate(data[7]),
                        data[8],
                        data[9],
                        data[10],
                        data[11],
                        data[12],
                        data[13]);
                list.add(b);
            }
        }
        return list;
    }

    public boolean addBookingList(List<Booking> list) {
        return mgmt.insertBookingList(list);
    }

    public String generateId() {
        id++;
        return "BOOK_ID-" + id;
    }

    public boolean updateCheckInAndCheckOutUsingBookingId(String id, String checkIn, String checkOut) {
        return mgmt.updateCheckInAndCheckOut(id, checkIn, checkOut);
    }

    public boolean updatePackageUsingBookingId(String id, String newPackage) {
        return mgmt.updatePackage(id, newPackage);
    }

    public boolean updateExtraAccessUsingBookingId(String id, String ac, String pool, String gym) {
        return mgmt.updateExtraAccess(id, ac, pool, gym);
    }

    public boolean deleteBookingDetailsFromDBUsingBookingId(String id) {
        return mgmt.cancelBooking(id);
    }

    public Booking viewBookingDetails(String id) {
        return mgmt.getBookingDetails(id);
    }
}