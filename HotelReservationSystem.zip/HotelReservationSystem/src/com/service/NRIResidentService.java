package com.service;

import java.util.ArrayList;
import java.util.List;
import com.management.NRIResidentManagement;
import com.model.NRIResident;
import com.utili.ApplicationUtil;

public class NRIResidentService {
    NRIResidentManagement mgmt = new NRIResidentManagement();
    int id = 0;
    ApplicationUtil au = new ApplicationUtil();

    public List<NRIResident> buildNRIResidentList(List<String> lines) {
        List<NRIResident> list = new ArrayList<>();
        for (String line : lines) {
            String[] data = line.split(":");
            if (data.length == 15) {
                NRIResident r = new NRIResident(generateId(),
                    data[0],
                    au.stringToInt(data[1]),
                    data[2],
                    au.stringToLong(data[3]),
                    data[4],
                    data[5],
                    au.stringToInt(data[6]),
                    au.stringToInt(data[7]),
                    au.stringToInt(data[8]),
                    au.stringToInt(data[9]),
                    data[10],
                    data[11],
                    data[12],
                    data[13],
                    data[14]);
                list.add(r);
            }
        }
        addNRIResidentList(list);
        return list;
    }

    public boolean addNRIResidentList(List<NRIResident> list) {
        return mgmt.insertNRIResidentList(list);
    }

    public String generateId() {
        id++;
        return "NRI_ID-" + id;
    }

    public boolean updateNRIResidentPhoneNumberUsingResidentId(String id, long phone) {
        return mgmt.updatePhoneByResidentId(id, phone);
    }

    public boolean updateOccupancyUsingResidentId(String id, int ad, int ch12, int ch5) {
        return mgmt.updateOccupancyByResidentId(id, ad, ch12, ch5);
    }

    public boolean updateNRIResidentPhoneNumberUsingPassportNumber(String passport, long phone) {
        return mgmt.updatePhoneByPassport(passport, phone);
    }

    public boolean updateOccupancyUsingPassportNumber(String passport, int ad, int ch12, int ch5) {
        return mgmt.updateOccupancyByPassport(passport, ad, ch12, ch5);
    }

    public boolean deleteNRIResidentDetailsFromDB(String id) {
        return mgmt.deleteNRIResident(id);
    }
}
