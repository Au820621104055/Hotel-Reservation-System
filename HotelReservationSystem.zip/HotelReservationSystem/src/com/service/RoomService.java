package com.service;

import java.util.ArrayList;
import java.util.List;

import com.model.Room;
import com.management.RoomManagement;
import com.utili.ApplicationUtil;

public class RoomService {
    RoomManagement mgmt = new RoomManagement();
    ApplicationUtil au = new ApplicationUtil();

    public List<Room> buildRoomList(List<String> lines) {
        List<Room> list = new ArrayList<>();
        for (String line : lines) {
            String[] data = line.split(":");
            if (data.length == 7) {
                Room r = new Room(data[0], data[1], data[2],
                        au.stringToInt(data[3]), data[4], data[5], data[6]);
                list.add(r);
            }
        }
        return list;
    }

    public boolean addRoomList(List<Room> list) {
        return mgmt.insertRoomList(list);
    }

    public boolean updateOccupiedStatus(String roomNumber, String status) {
        return mgmt.updateOccupiedStatus(roomNumber, status);
    }

    public boolean deleteRoomDetailsFromDBUsingFloorNumber(String floor) {
        return mgmt.deleteRoomDetailsUsingFloor(floor);
    }

    public boolean deleteRoomDetailsFromDBUsingRoomNumber(String room) {
        return mgmt.deleteRoomDetailsUsingRoom(room);
    }
}
