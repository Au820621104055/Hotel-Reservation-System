package com.service;

import java.util.ArrayList;
import java.util.List;

import com.management.PaymentManagement;
import com.model.Payment;
import com.utili.ApplicationUtil;

public class PaymentService {
    PaymentManagement mgmt = new PaymentManagement();
    ApplicationUtil au = new ApplicationUtil();
    int id = 0;

    public List<Payment> buildPaymentList(List<String> payBookingId) {
        List<Payment> list = new ArrayList<>();
        for (String line : payBookingId) {
            String[] data = line.split(":");
            if (data.length == 10) {
                Payment p = new Payment(
                    generateId(),
                    data[0],
                    data[1],
                    data[2],
                    data[3],
                    au.stringToDate(data[4]),
                    au.stringToDate(data[5]),
                    au.stringToDate(data[6]),
                    data[7],
                    au.stringToDouble(data[8])
                );
                list.add(p);
            }
        }
        return list;
    }

    public boolean addPaymentList(List<Payment> list) {
        return mgmt.insertPaymentList(list);
    }

    public String generateId() {
        id++;
        return "PAY_ID-" + id;
    }

    public Payment viewPaymentDetails(String paymentId) {
        return mgmt.viewPaymentDetails(paymentId);
    }
}