package com.utili;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ApplicationUtil {

    public int stringToInt(String str) {
        return Integer.parseInt(str);
    }

    public double stringToDouble(String str) {
        return Double.parseDouble(str);
    }

    public long stringToLong(String str) {
        return Long.parseLong(str);
    }

    // Updated date parser to accept yyyy-MM-dd format strictly
    public Date stringToDate(String str) {
        if (str == null || str.trim().isEmpty()) {
            System.out.println("Date cannot be empty.");
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false); // strict parsing

        try {
            java.util.Date date = sdf.parse(str.trim());
            return new java.sql.Date(date.getTime());
        } catch (Exception e) {
            System.out.println("Please provide the correct date in yyyy-MM-dd format.");
            return null;
        }
    }

    // Helper method to read integer input robustly
    public static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid number, try again: ");
            }
        }
    }

    // Read lines until 'exit' is typed
    public static List<String> readLines(Scanner scanner) {
        List<String> lines = new ArrayList<>();
        while (true) {
            String line = scanner.nextLine();
            if (line.equalsIgnoreCase("exit"))
                break;
            lines.add(line);
        }
        return lines;
    }

    // Read a valid date from Scanner with prompt and retry
    public Date readValidDate(Scanner scanner, String prompt) {
        Date date = null;
        while (date == null) {
            System.out.print(prompt);
            String input = scanner.nextLine();
            date = stringToDate(input);
        }
        return date;
    }
}
