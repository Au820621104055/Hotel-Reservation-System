package com.management;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.model.Booking;
import com.utili.ApplicationUtil;

public class BookingManagement {
    static Connection con = null;
    ApplicationUtil au = new ApplicationUtil();

    public static Connection getConnection() {
        con = DBConnectionManager.getConnection();
        return con;
    }

    public boolean insertBookingList(List<Booking> list) {
        int result = 0;
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "INSERT INTO booking (booking_id, resident_id, resident_name, duration_of_stay, number_of_adults, number_of_children_above12, number_of_children_above5, check_in_date, check_out_date, floor_number, room_number, preferred_package, ac_access, pool_access, gym_access) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            for (Booking b : list) {
                ps.setString(1, b.getBookingId());
                ps.setString(2, b.getResidentId());
                ps.setString(3, b.getResidentName());
                ps.setInt(4, b.getDurationOfStay());
                ps.setInt(5, b.getNumberOfAdults());
                ps.setInt(6, b.getNumberOfChildrenAbove12());
                ps.setInt(7, b.getNumberOfChildrenAbove5());
                ps.setDate(8, (Date) b.getCheckInDate());
                ps.setDate(9, (Date) b.getCheckOutDate());
                ps.setString(10, b.getFloorNumber());
                ps.setString(11, b.getRoomNumber());
                ps.setString(12, b.getPreferredPackage());
                ps.setString(13, b.getAcAccess());
                ps.setString(14, b.getPoolAccess());
                ps.setString(15, b.getGymAccess());
                result += ps.executeUpdate();
            }
            return result == list.size();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateCheckInAndCheckOut(String bookingId, String checkIn, String checkOut) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "UPDATE booking SET check_in_date=?, check_out_date=? WHERE booking_id=?");
            ps.setDate(1, au.stringToDate(checkIn));
            ps.setDate(2, au.stringToDate(checkOut));
            ps.setString(3, bookingId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updatePackage(String bookingId, String newPackage) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "UPDATE booking SET preferred_package=? WHERE booking_id=?");
            ps.setString(1, newPackage);
            ps.setString(2, bookingId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateExtraAccess(String bookingId, String ac, String pool, String gym) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "UPDATE booking SET ac_access=?, pool_access=?, gym_access=? WHERE booking_id=?");
            ps.setString(1, ac);
            ps.setString(2, pool);
            ps.setString(3, gym);
            ps.setString(4, bookingId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean cancelBooking(String bookingId) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "DELETE FROM booking WHERE booking_id=?");
            ps.setString(1, bookingId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Booking getBookingDetails(String bookingId) {
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT * FROM booking WHERE booking_id=?");
            ps.setString(1, bookingId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Booking(
                    rs.getString("booking_id"),
                    rs.getString("resident_id"),
                    rs.getString("resident_name"),
                    rs.getInt("duration_of_stay"),
                    rs.getInt("number_of_adults"),
                    rs.getInt("number_of_children_above12"),
                    rs.getInt("number_of_children_above5"),
                    rs.getDate("check_in_date"),
                    rs.getDate("check_out_date"),
                    rs.getString("floor_number"),
                    rs.getString("room_number"),
                    rs.getString("preferred_package"),
                    rs.getString("ac_access"),
                    rs.getString("pool_access"),
                    rs.getString("gym_access"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
