package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ManagerManagement {

    static Connection con = null;

    public static Connection getConnection() {
        con = DBConnectionManager.getConnection();
        return con;
    }

    public List<String> viewBookingDetails() {
        List<String> bookings = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT * FROM booking");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Booking ID: ").append(rs.getString("booking_id")).append(", ");
                sb.append("Resident Name: ").append(rs.getString("resident_name")).append(", ");
                sb.append("Check-in: ").append(rs.getDate("check_in_date")).append(", ");
                sb.append("Check-out: ").append(rs.getDate("check_out_date")).append(", ");
                sb.append("Room No: ").append(rs.getString("room_number")).append(", ");
                sb.append("Floor: ").append(rs.getString("floor_number")).append(", ");
                sb.append("Package: ").append(rs.getString("preferred_package"));
                bookings.add(sb.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookings;
    }

    public List<String> viewAvailableRooms() {
        List<String> availableRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM room WHERE is_occupied='no'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                availableRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return availableRooms;
    }

    public List<String> viewOccupiedRooms() {
        List<String> occupiedRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM room WHERE is_occupied='yes'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                occupiedRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return occupiedRooms;
    }

    public List<String> viewAvailableRoomsByFloor(String floor) {
        List<String> availableRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM room WHERE is_occupied='no' AND floor_number=?");
            ps.setString(1, floor);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                availableRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return availableRooms;
    }

    public List<String> viewOccupiedRoomsByFloor(String floor) {
        List<String> occupiedRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM room WHERE is_occupied='yes' AND floor_number=?");
            ps.setString(1, floor);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                occupiedRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return occupiedRooms;
    }

    public List<String> viewOccupiedRoomsByCheckInDate(String date) {
        List<String> occupiedRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM booking WHERE check_in_date=?");
            ps.setDate(1, java.sql.Date.valueOf(date));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                occupiedRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return occupiedRooms;
    }

    public List<String> viewOccupiedRoomsByCheckOutDate(String date) {
        List<String> occupiedRooms = new ArrayList<>();
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT room_number FROM booking WHERE check_out_date=?");
            ps.setDate(1, java.sql.Date.valueOf(date));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                occupiedRooms.add(rs.getString("room_number"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return occupiedRooms;
    }
}