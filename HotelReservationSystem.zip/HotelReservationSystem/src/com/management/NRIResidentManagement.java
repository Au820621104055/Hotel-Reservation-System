package com.management;
	import java.sql.*;
	import java.util.List;
	import com.model.NRIResident;

	public class NRIResidentManagement {
	    static Connection con = null;

	    public static Connection getConnection() {
	        con = DBConnectionManager.getConnection();
	        return con;
	    }

	    public boolean insertNRIResidentList(List<NRIResident> list) {
	        int result = 0;
	        try {
	            PreparedStatement ps = getConnection().prepareStatement(
	                "INSERT INTO nriresident (resident_id, resident_name, age, gender, contact_number, email, address, number_of_adults, number_of_children_above12, number_of_children_above5, duration_of_stay, resident_type, passport_no, passport_type, nationality, purposeforvisit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
	            );
	            for (NRIResident r : list) {
	                ps.setString(1, r.getResidentId());
	                ps.setString(2, r.getResidentName());
	                ps.setInt(3, r.getAge());
	                ps.setString(4, r.getGender());
	                ps.setLong(5, r.getContactNumber());
	                ps.setString(6, r.getEmail());
	                ps.setString(7, r.getAddress());
	                ps.setInt(8, r.getNumberOfAdults());
	                ps.setInt(9, r.getNumberOfChildrenAbove12());
	                ps.setInt(10, r.getNumberOfChildrenAbove5());
	                ps.setInt(11, r.getDurationOfStay());
	                ps.setString(12, r.getResidentType());
	                ps.setString(13, r.getPassportNo());
	                ps.setString(14, r.getPassportType());
	                ps.setString(15, r.getNationality());
	                ps.setString(16, r.getPurposeForVisit());
	                result += ps.executeUpdate();
	            }
	            return result == list.size();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    public boolean updatePhoneByResidentId(String id, long phone) {
	        try {
	            PreparedStatement ps = getConnection().prepareStatement("UPDATE nriresident SET contact_number=? WHERE resident_id=?");
	            ps.setLong(1, phone);
	            ps.setString(2, id);
	            return ps.executeUpdate() > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    public boolean updateOccupancyByResidentId(String id, int ad, int ch12, int ch5) {
	        try {
	            PreparedStatement ps = getConnection().prepareStatement("UPDATE nriresident SET number_of_adults=?, number_of_children_above12=?, number_of_children_above5=? WHERE resident_id=?");
	            ps.setInt(1, ad);
	            ps.setInt(2, ch12);
	            ps.setInt(3, ch5);
	            ps.setString(4, id);
	            return ps.executeUpdate() > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    public boolean updatePhoneByPassport(String passport, long phone) {
	        try {
	            PreparedStatement ps = getConnection().prepareStatement("UPDATE nriresident SET contact_number=? WHERE passport_no=?");
	            ps.setLong(1, phone);
	            ps.setString(2, passport);
	            return ps.executeUpdate() > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    public boolean updateOccupancyByPassport(String passport, int ad, int ch12, int ch5) {
	        try {
	            PreparedStatement ps = getConnection().prepareStatement("UPDATE nriresident SET number_of_adults=?, number_of_children_above12=?, number_of_children_above5=? WHERE passport_no=?");
	            ps.setInt(1, ad);
	            ps.setInt(2, ch12);
	            ps.setInt(3, ch5);
	            ps.setString(4, passport);
	            return ps.executeUpdate() > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    public boolean deleteNRIResident(String id) {
	        try {
	            PreparedStatement ps = getConnection().prepareStatement("DELETE FROM nriresident WHERE resident_id=?");
	            ps.setString(1, id);
	            return ps.executeUpdate() > 0;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	}


