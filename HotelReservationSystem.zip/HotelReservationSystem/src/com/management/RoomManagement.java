package com.management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.model.Room;

public class RoomManagement {
    static Connection con = null;

    public static Connection getConnection() {
        con = DBConnectionManager.getConnection();
        return con;
    }

    public boolean insertRoomList(List<Room> list) {
        int result = 0;
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                    "INSERT INTO room (room_number, floor_number, is_occupied, max_occupancy, has_ac, has_swimming_pool_access, has_gym_access) VALUES (?, ?, ?, ?, ?, ?, ?)");
            for (Room r : list) {
                ps.setString(1, r.getRoomNumber());
                ps.setString(2, r.getFloorNumber());
                ps.setString(3, r.getIsOccupied());
                ps.setInt(4, r.getMaxOccupancy());
                ps.setString(5, r.getHasAc());
                ps.setString(6, r.getHasSwimmingPoolAccess());
                ps.setString(7, r.getHasGymAccess());
                result += ps.executeUpdate();
            }
            return result == list.size();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateOccupiedStatus(String roomNumber, String status) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                    "UPDATE room SET is_occupied=? WHERE room_number=?");
            ps.setString(1, status);
            ps.setString(2, roomNumber);
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteRoomDetailsUsingFloor(String floor) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                    "DELETE FROM room WHERE floor_number=?");
            ps.setString(1, floor);
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteRoomDetailsUsingRoom(String roomNumber) {
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                    "DELETE FROM room WHERE room_number=?");
            ps.setString(1, roomNumber);
            int result = ps.executeUpdate();
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}