package com.management;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.model.Payment;

public class PaymentManagement {
    static Connection con = null;

    public static Connection getConnection() {
        con = DBConnectionManager.getConnection();
        return con;
    }

    public boolean insertPaymentList(List<Payment> list) {
        int result = 0;
        try {
            PreparedStatement ps = getConnection().prepareStatement(
                "INSERT INTO payment (payment_id, booking_id, resident_name, floor_number, room_number, check_in_date, check_out_date, payment_date, payment_method, bill_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            for (Payment p : list) {
                ps.setString(1, p.getPaymentId());
                ps.setString(2, p.getBookingId());
                ps.setString(3, p.getResidentName());
                ps.setString(4, p.getFloorNumber());
                ps.setString(5, p.getRoomNumber());
                ps.setDate(6, (Date) p.getCheckInDate());
                ps.setDate(7, (Date) p.getCheckOutDate());
                ps.setDate(8, (Date) p.getPaymentDate());
                ps.setString(9, p.getPaymentMethod());
                ps.setDouble(10, p.getBillAmount());
                result += ps.executeUpdate();
            }
            return result == list.size();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean checkIdExists(String paymentId) {
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT payment_id FROM payment WHERE payment_id=?");
            ps.setString(1, paymentId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Payment viewPaymentDetails(String paymentId) {
        try {
            PreparedStatement ps = getConnection().prepareStatement("SELECT * FROM payment WHERE payment_id=?");
            ps.setString(1, paymentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Payment(
                    rs.getString("payment_id"),
                    rs.getString("booking_id"),
                    rs.getString("resident_name"),
                    rs.getString("floor_number"),
                    rs.getString("room_number"),
                    rs.getDate("check_in_date"),
                    rs.getDate("check_out_date"),
                    rs.getDate("payment_date"),
                    rs.getString("payment_method"),
                    rs.getDouble("bill_amount")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
